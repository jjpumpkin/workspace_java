package practics;

public class Result02 {

	public static void main(String[] args) {
	int z=10;
	for(int i=9; i>=1; i--) {
		z*=i;
	}	
	System.out.println("결과: "+z);
	
	
	int k=1;
	for(int i=2; i<=10; i++) {
		k*=i;
	
	}
	System.out.println("결과: "+k);
	long v=15;
	for(int i=14; i>=1; i--) {
		v*=i;
	}
	System.out.println("결과: "+v);
	
	long r=1;
	for(int i=2; i<=15; i++) {
		r*=i;
	}
	System.out.println("결과: "+r);
	
	long result = 1;
	for(int i =1; i <=15; i ++) {
		result *=i;
	}
	System.out.println(result);
	
	
	
	}

}
