package practics;

public class Result06 {

	public static void main(String[] args) {
	

	}

}
