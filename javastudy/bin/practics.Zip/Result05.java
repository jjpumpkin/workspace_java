package practics;

public class Result05 {

}
