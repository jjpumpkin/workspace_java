package practics;

public class Rexult04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
